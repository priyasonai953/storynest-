TinyTales V1 frontend redesign
- Personalized magical storybook homepage
- Baby, Couple, Family, Best Friend and Someone Special
- Occasion selector including Durga Puja and Bhai Phonta
- English / Bengali / Hindi
- Page pricing: India INR + International USD
- 50% real-photo + 50% storybook concept preview
- Occasion-based TinyTales signature concept
- Frontend prototype only

Not connected yet:
- AI story/image generation
- secure photo storage
- user accounts/database
- real payment
- PDF generation/download
- production authentication
